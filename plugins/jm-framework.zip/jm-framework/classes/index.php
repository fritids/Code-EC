<?php
// Safe directory
?>