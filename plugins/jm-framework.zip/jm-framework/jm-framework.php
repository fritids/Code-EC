<?php
/*
Plugin Name:  jm-framework
Plugin URI:  http://onewebcentric.com
Description:  Brings it all together
Version:  .01
Author URI:  http://onewebcentric.com
Author:  Jon McDonald of OneWebCentric
*/

/*
 * Define our plugin path
 */
define( 'JM_PATH', plugin_dir_path(__FILE__) );

//Includes code to create sliders
include_once( JM_PATH . '/classes/jm_event_functions.php');

?>